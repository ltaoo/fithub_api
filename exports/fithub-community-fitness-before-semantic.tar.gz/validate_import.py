#!/usr/bin/env python3
"""Read-only source DB; exercise all imports in memory, never import into the source."""
import argparse, hashlib, json, sqlite3, subprocess
from pathlib import Path

def validate(source_path):
 root=Path(__file__).parent
 sql=(root/'import_all.sql').read_text()
 source=sqlite3.connect(source_path.resolve().as_uri()+'?mode=ro',uri=True)
 c=sqlite3.connect(':memory:');source.backup(c)
 old_actions=c.execute('SELECT * FROM WORKOUT_ACTION ORDER BY id').fetchall()
 old_ids=[r[0] for r in old_actions]
 c.execute("UPDATE EQUIPMENT SET medias=? WHERE id=1",(json.dumps({'videos':['keep-existing-video'],'pics':['old']}),));c.commit()
 c.executescript(sql)
 assert [r for r in c.execute('SELECT * FROM WORKOUT_ACTION ORDER BY id') if r[0] in old_ids]==old_actions
 imported=c.execute('SELECT count(*) FROM WORKOUT_ACTION').fetchone()[0]
 old_id_set=set(old_ids)
 for r in c.execute('SELECT id,details,points,problems,extra_config,equipment_ids,muscle_ids,primary_muscle_ids,secondary_muscle_ids FROM WORKOUT_ACTION'):
  if r[0] in old_id_set:continue
  for value in r[1:5]:json.loads(value)
  for idx,table in [(5,'EQUIPMENT'),(6,'MUSCLE'),(7,'MUSCLE'),(8,'MUSCLE')]:
   for value in filter(None,r[idx].split(',')):
    assert c.execute('SELECT 1 FROM '+table+' WHERE id=? AND COALESCE(d,0)=0',(int(value),)).fetchone()
 manifest=json.loads((root/'equipment_sources.json').read_text())
 for r in manifest:
  filename=root/r['local_path'];assert hashlib.sha256(filename.read_bytes()).hexdigest()==r['sha256']
  media=json.loads(c.execute('SELECT medias FROM EQUIPMENT WHERE id=?',(r['id'],)).fetchone()[0])
  assert media['pics']==[r['public_url']]
 assert json.loads(c.execute('SELECT medias FROM EQUIPMENT WHERE id=1').fetchone()[0])['videos']==['keep-existing-video']
 tables=['WORKOUT_ACTION','MUSCLE','EQUIPMENT']
 snapshots={t:c.execute('SELECT * FROM '+t+' ORDER BY id').fetchall() for t in tables}
 c.executescript(sql)
 for t in tables:assert c.execute('SELECT * FROM '+t+' ORDER BY id').fetchall()==snapshots[t],t
 # Remove a newly imported row so that a later equipment conflict must roll back an earlier action insertion.
 new_id=c.execute('SELECT id FROM WORKOUT_ACTION WHERE id NOT IN ('+','.join('?'*len(old_ids))+') LIMIT 1',old_ids).fetchone() if old_ids else c.execute('SELECT id FROM WORKOUT_ACTION LIMIT 1').fetchone()
 if new_id:c.execute('DELETE FROM WORKOUT_ACTION WHERE id=?',new_id)
 c.execute("UPDATE EQUIPMENT SET name='occupied-by-other',zh_name='occupied-by-other' WHERE id=1");c.commit()
 snapshots={t:c.execute('SELECT * FROM '+t+' ORDER BY id').fetchall() for t in tables}
 try:c.executescript(sql)
 except sqlite3.IntegrityError:c.rollback()
 else:raise AssertionError('Expected fixed-ID conflict')
 for t in tables:assert c.execute('SELECT * FROM '+t+' ORDER BY id').fetchall()==snapshots[t],t
 # Fresh schema, no business seeds: fixed references must be created by the import itself.
 fresh=sqlite3.connect(':memory:')
 for t in tables:fresh.execute(source.execute('SELECT sql FROM sqlite_master WHERE name=?',(t,)).fetchone()[0])
 fresh.executescript(sql)
 expected=len({r['name'].strip().lower() for r in json.loads((root/'exercises.json').read_text())})
 assert fresh.execute('SELECT count(*) FROM WORKOUT_ACTION').fetchone()[0]==expected
 # Decoding check uses macOS sips when available; downloaded magic headers were also checked.
 import shutil
 if shutil.which('sips'):
  for r in manifest:
   run=subprocess.run(['sips','-g','pixelWidth','-g','pixelHeight',str(root/r['local_path'])],capture_output=True,text=True)
   assert run.returncode==0 and 'pixelWidth: <nil>' not in run.stdout and 'pixelHeight: <nil>' not in run.stdout,r['local_path']
 report={'source_actions':len(old_actions),'new_actions':imported-len(old_actions),'total_actions':imported,'fresh_schema_actions':expected,'equipment_images':len(manifest),'repeat_import':'unchanged','fixed_id_conflict':'rolled back entire import','original_actions':'unchanged','image_checksums':'passed','json_and_references':'passed','existing_media_other_keys':'preserved'}
 print(json.dumps(report,ensure_ascii=False,indent=2))
 source.close();c.close();fresh.close()
 return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('database',type=Path);args=p.parse_args();validate(args.database)

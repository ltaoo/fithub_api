#!/usr/bin/env python3
"""Generate a standalone, append-only SQLite import for FitHub."""
import argparse, hashlib, json
from pathlib import Path

muscles = {
 'abdominals': ('Abdominals','腹直肌'), 'abductors': ('Gluteus medius','臀中肌'),
 'adductors': ('Hip adductors','髋内收肌群'), 'biceps': ('Biceps brachii','肱二头肌'),
 'calves': ('Calf muscles','小腿肌群'), 'chest': ('Pectoralis major','胸大肌'),
 'forearms': ('Forearm muscles','前臂肌群'), 'glutes': ('Gluteus maximus','臀大肌'),
 'hamstrings': ('Hamstrings','股二头肌'), 'lats': ('Latissimus dorsi','背阔肌'),
 'lower back': ('Erector spinae','竖脊肌'), 'middle back': ('Rhomboids','菱形肌'),
 'neck': ('Neck muscles','颈部肌群'), 'quadriceps': ('Quadriceps','股四头肌'),
 'shoulders': ('Deltoid','三角肌'), 'traps': ('Trapezius','斜方肌'),
 'triceps': ('Triceps brachii','肱三头肌'),
}
equipment = {
 'bands': ('resistance_band','弹力带'), 'barbell': ('barbell','杠铃'),
 'cable': ('cable_machine','龙门架'), 'dumbbell': ('dumbbell','哑铃'),
 'e-z curl bar': ('ez_curl_bar','EZ曲杆'), 'exercise ball': ('yoga_ball','瑜伽球'),
 'foam roll': ('foam_roller','泡沫轴'), 'kettlebells': ('kettlebell','壶铃'),
 'machine': ('machine','通用健身器械'), 'medicine ball': ('medicine_ball','药球'),
 'other': ('other','其他器械'),
}
types = {'cardio':'cardio','stretching':'static_stretch','plyometrics':'performance',
 'strength':'resistance','powerlifting':'resistance','olympic weightlifting':'resistance','strongman':'comprehensive'}
levels = {'beginner':3,'intermediate':5,'expert':8}
# Fixed IDs from the project's seeded database; supplemental IDs are explicitly reserved.
muscle_ids = {'abdominals':12,'abductors':19,'adductors':20,'biceps':2,'calves':21,'chest':6,'forearms':22,'glutes':8,'hamstrings':10,'lats':7,'lower back':16,'middle back':15,'neck':23,'quadriceps':9,'shoulders':4,'traps':5,'triceps':3}
equipment_ids = {'bands':17,'barbell':2,'cable':13,'dumbbell':1,'e-z curl bar':43,'exercise ball':19,'foam roll':18,'kettlebells':16,'machine':44,'medicine ball':45,'other':46}

def quote(value):
 return "'" + str(value).replace("'", "''") + "'"

def encoded(value):
 return quote(json.dumps(value,ensure_ascii=False,separators=(',',':')))

def generate(source, output, revision='main'):
 records=json.loads(source.read_text())
 lines=[
 '-- FitHub community exercise import (SQLite only).',
 '-- Source: https://github.com/yuhonas/free-exercise-db ; license: Unlicense.',
 '-- Source revision: '+revision,
 '-- Source SHA256: '+hashlib.sha256(source.read_bytes()).hexdigest(),
 '-- Records: '+str(len(records)),
 '-- Requires current migrated FitHub schema; run after database migrations.',
 '-- Append only. Existing names and IDs remain unchanged. English content is retained.',
 '-- On error stop execution and roll back; use sqlite3 -bail (see README).',
 'BEGIN IMMEDIATE;',
 'CREATE TEMP TABLE fithub_import_id_guard (valid INTEGER NOT NULL CHECK(valid = 1));',
 ]
 for table,mapping,id_mapping in [('MUSCLE',muscles,muscle_ids),('EQUIPMENT',equipment,equipment_ids)]:
  for key,(name,zh_name) in mapping.items():
   target_id=id_mapping[key]
   match=f"(lower(trim(name)) = lower({quote(name)}) OR zh_name = {quote(zh_name)}) AND COALESCE(d,0) = 0"
   lines.append(f'-- {table} ID {target_id}: {name} / {zh_name}')
   lines.append(f'INSERT INTO fithub_import_id_guard (valid) SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM {table} WHERE id = {target_id} AND NOT ({match})) THEN 1 ELSE 0 END;')
   fields='id,name,zh_name,overview,tags,features,d' if table=='MUSCLE' else 'id,name,zh_name,alias,overview,medias,tags,d'
   values=[str(target_id),quote(name),quote(zh_name),"''","''","'[]'",'0'] if table=='MUSCLE' else [str(target_id),quote(name),quote(zh_name),"''","''","'{}'","''",'0']
   lines.append(f'INSERT INTO {table} ({fields}) SELECT '+','.join(values)+f' WHERE NOT EXISTS (SELECT 1 FROM {table} WHERE id = {target_id});')
 def ids(keys):
  return quote(','.join(str(i) for i in sorted({muscle_ids[k] for k in keys})))
 columns=['status','name','zh_name','alias','overview','type','level','tags1','tags2','details','points','problems','equipment_ids','muscle_ids','primary_muscle_ids','secondary_muscle_ids','alternative_action_ids','advanced_action_ids','regressed_action_ids','owner_id','score','extra_config','sort_idx','pattern','d','cover_url']
 for r in records:
  assert r['category'] in types and r['level'] in levels
  assert all(k in muscles for k in r['primaryMuscles']+r['secondaryMuscles'])
  eq=r.get('equipment')
  assert eq in equipment or eq in [None,'body only']
  images=['https://raw.githubusercontent.com/yuhonas/free-exercise-db/'+revision+'/exercises/'+p for p in r.get('images',[])]
  extra={'source':'yuhonas/free-exercise-db','source_id':r['id'],'source_revision':revision,'license':'Unlicense','language':'en','images':images,'force':r.get('force'),'mechanic':r.get('mechanic'),'category':r['category'],'equipment':eq,'primary_muscles':r['primaryMuscles'],'secondary_muscles':r['secondaryMuscles'],'difficulty_mapping':'beginner=3,intermediate=5,expert=8'}
  vals=['1',quote(r['name']),quote(r['name']),quote(r['id']),"''",quote(types[r['category']]),str(levels[r['level']]),quote(','.join(r['primaryMuscles'])),quote(','.join(filter(None,['community',r.get('force'),r.get('mechanic')]))),encoded({'start_position':'','steps':r['instructions']}),"'[]'","'[]'",
   quote(equipment_ids[eq]) if eq in equipment else "''",
   ids(sorted(set(r['primaryMuscles']+r['secondaryMuscles']))),ids(r['primaryMuscles']),ids(r['secondaryMuscles']),"''","''","''",'0','0',encoded(extra),'0',"''",'0',quote(images[0] if images else '')]
  lines.append('INSERT INTO WORKOUT_ACTION ('+','.join(columns)+') SELECT '+','.join(vals)+' WHERE NOT EXISTS (SELECT 1 FROM WORKOUT_ACTION WHERE lower(trim(name)) = lower('+quote(r['name'])+'));')
 lines.extend(['DROP TABLE fithub_import_id_guard;','COMMIT;',''])
 output.write_text('\n'.join(lines))
 print(f'Generated {len(records)} records: {output} ({output.stat().st_size} bytes)')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--revision',default='main');a=p.parse_args();generate(a.source,a.output,a.revision)

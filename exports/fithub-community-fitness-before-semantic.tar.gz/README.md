# FitHub 社区动作与器械图片导入包

适用于已运行当前项目数据库迁移的 **SQLite** 数据库。无需导入程序，也无需访问原 FitHub 服务器。

## 文件

- `import_all.sql`：一次导入动作、肌肉、器械和器械图片关联，整个文件使用同一个事务。
- `community_workout_actions.sql`：仅导入社区动作，876 条源记录，按 `lower(trim(name))` 去重。
- `equipment_photos.sql`：仅创建缺失器械并更新 46 个固定器械 ID 的 `medias.pics`，保留 `medias` 的其他键。
- `media/equipment/`：已下载的 46 张实际图片，SQL 使用站内 `/media/equipment/...` 地址。
- `equipment_sources.json`：器械 ID、名称、商品页、原图地址、文件大小与 SHA256。
- `exercises.json`、`generate.py`、`SOURCE_REVISION`：原始社区数据与可重复生成动作 SQL 的脚本。
- `download_equipment.py`：从来源清单重新下载器械图片并生成图片 SQL。
- `LICENSE.free-exercise-db.md`：动作数据上游 Unlicense。

## 部署与一键导入

把 `fithub-community-fitness.tar.gz` 上传到服务器，在 API 项目根目录执行（示例数据库 `myapi.db`，请按实际 `DB_PATH` 修改）：

```sh
# 解压部署包
mkdir -p imports/community_fitness
tar -xzf fithub-community-fitness.tar.gz -C imports/community_fitness

# 保存图片到 Go 服务静态目录
mkdir -p dist/h5/media/equipment
cp imports/community_fitness/media/equipment/* dist/h5/media/equipment/

# 同时保留到 H5 源码静态目录，避免下次 Vite 构建清空 dist 后丢图
mkdir -p h5/public/media/equipment
cp imports/community_fitness/media/equipment/* h5/public/media/equipment/

# 使用 SQLite 自身备份命令，包含 WAL 中已经提交的数据
sqlite3 myapi.db ".backup 'myapi.before-community.db'"

# 一条命令导入。遇到固定 ID 冲突或结构不兼容时立即退出、回滚事务。
sqlite3 -bail -cmd '.timeout 10000' myapi.db < imports/community_fitness/import_all.sql
```

如果 `STATIC_DIR` 不是 `./dist`，将图片复制到 `$STATIC_DIR/h5/media/equipment/`。无需重启 Go 服务。
数据库须为已经存在的目标库，先确认路径；不要误建新的空数据库。
支持 SQL 上传的数据库管理工具可执行 `import_all.sql`，但应启用“遇错停止并回滚”。SQL 只写关联，图片目录必须一起部署。

只导入动作或图片时，将上述 SQL 文件名换成对应单独文件即可。图片 SQL 需要 SQLite JSON 函数；当前项目环境已验证支持。

## 固定 ID

原数据库的 ID 不变。脚本不按名字动态寻找其他编号；只检查指定 ID 的名称是否与预期一致。
缺失的固定编号会被创建，已占用且名称不一致或已删除的编号会触发 CHECK 失败并回滚，不会静默覆盖。

新增肌肉 ID：19 臀中肌；20 髋内收肌群；21 小腿肌群；22 前臂肌群；23 颈部肌群。
新增器械 ID：43 EZ曲杆；44 通用健身器械；45 药球；46 其他器械。
ID 1–42 沿用项目既有器械定义。ID 9 为腿部推蹬机、10 为腿部伸展机、11 为腿部弯举机；原数据库英文 name 有历史错配，因此图片按 ID 与中文名称对应。
“通用健身器械”和“其他器械”的图片分别采用综合训练器、负重背心作为代表，并非所有器械的通用外观。

## 动作映射与限制

- 新动作自动分配 ID，已存在同英文名的动作不覆盖、不修改，既有计划关联保持不变。
- 当前 422 条动作的数据库副本中，新增 582 条，合计 1004 条；实际数量取决于服务器已有数据。
- `zh_name` 暂以英文名填充，保证页面可以展示；动作说明保留原英文，不伪造中文翻译或错误纠正说明。
- `details` 使用现有前端兼容的 `start_position`、`steps`；`points`、`problems` 为合法空数组。
- 难度：beginner=3、intermediate=5、expert=8，是本导入包的转换规则，并非上游数值标准。
- 肌肉映射按上游部位分类处理，例如 middle back 对应菱形肌、lower back 对应竖脊肌；不同分类体系并非完全等价。上游分类保留在 JSON 元数据中。
- 无器械和未注明器械的动作使用空 `equipment_ids`；machine 和 other 使用上述通用分类。
- 现有软删除动作也参与英文名去重，不会擅自恢复。
- 动作图片 URL 保留上游指定版本的 GitHub 链接，保存在 `cover_url` 与 `extra_config.images`；本包下载的本地图片仅是器械商品图片。

## 来源

动作：https://github.com/yuhonas/free-exercise-db （Unlicense）。SQL 头部与 SOURCE_REVISION 记录精确版本及原始 JSON 校验值。

器械商品图片来自 https://shop.lifefitness.com/ 、https://repfitness.com/ 、https://bellsofsteel.us/ 、https://titan.fitness/ 、https://precisionperformances.com/ 与 https://www.titaniumstrength.fr/ 。具体商品页、原图链接、文件校验值均保留在 equipment_sources.json。

商城商品图片并非上游动作数据的 Unlicense 内容；未确认有开放授权。公开或商业使用前应确认图片使用权，或替换成自有、已授权图片。

## 验证

已在当前数据库的独立副本及空业务表结构上验证导入、重复导入、所有新动作的 JSON、固定 ID 引用、图片文件校验以及冲突回滚。未对运行中的实际数据库执行导入。
未调用浏览器；部署后请手动验证器械列表、动作详情与图片展示。
